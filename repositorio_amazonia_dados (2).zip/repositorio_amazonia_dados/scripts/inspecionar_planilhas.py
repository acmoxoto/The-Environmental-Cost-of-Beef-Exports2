"""Inspeciona os arquivos Excel armazenados na pasta data."""

from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data"

def main() -> None:
    arquivos = sorted(DATA_DIR.glob("*.xlsx"))
    if not arquivos:
        raise FileNotFoundError("Nenhum arquivo .xlsx encontrado na pasta data.")

    for arquivo in arquivos:
        print(f"\n{'=' * 80}\nARQUIVO: {arquivo.name}")
        excel = pd.ExcelFile(arquivo)
        print("PLANILHAS:", ", ".join(excel.sheet_names))

        for planilha in excel.sheet_names:
            df = pd.read_excel(arquivo, sheet_name=planilha)
            print(f"\nPlanilha: {planilha}")
            print(f"Dimensões: {df.shape[0]} linhas x {df.shape[1]} colunas")
            print("Colunas:", list(df.columns))
            print(df.head().to_string(index=False))

if __name__ == "__main__":
    main()
